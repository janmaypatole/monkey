
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score

function preload(){
  createCanvas(600,600)
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
  
  monkey = createSprite(200,200,100,100) 
 monkey.scale = 0.5 
 monkey.addAnimation("moving",monkey_running);

  ground = createSprite()
  ground.velocity = -2
  if(ground.x<0)
  ground.addAnimation(ground.Image)
    ground.x = ground.width/2
}


function draw() {
ground = 300

  if(ground.x<0)
  ground.x =ground/width2

  if(keydown(space))
    monkey.velocity = -12

  monkey.collide(ground)
  drawSprite();
}




